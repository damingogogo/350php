<?php
// linked list classroom sample
echo "linked list sample";
