Data structure classroom cases.
This archive opens normally and contains sample teaching material.
